// ============================================================
// FIREBASE CONFIGURATION
// Replace with your own Firebase project config
// Get from: Firebase Console → Project Settings → Your apps
// ============================================================

const FIREBASE_CONFIG = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  databaseURL: "https://YOUR_PROJECT-default-rtdb.firebaseio.com",
  projectId: "YOUR_PROJECT",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};

// GitHub Pages API URL (replace with your GitHub username and repo name)
const STOCK_API_URL = "https://YOUR_USERNAME.github.io/YOUR_REPO/api/stocks.json";

// ============================================================
// GAME SETTINGS
// ============================================================
const GAME_CONFIG = {
  INITIAL_COINS: 10000,
  HOURLY_BONUS: 500,
  BUY_FEE_RATE: 0.001425,   // 0.1425% (台灣證券交易手續費)
  SELL_FEE_RATE: 0.001425,   // 0.1425%
  SELL_TAX_RATE: 0.003,      // 0.3% 證券交易稅 (sell only)
  MIN_FEE: 1,                // 最低手續費 $1
  CHAT_REFRESH_INTERVAL: 3000,    // ms
  LEADERBOARD_REFRESH: 30000,     // ms
  STOCK_REFRESH_INTERVAL: 300000, // 5 min
};
