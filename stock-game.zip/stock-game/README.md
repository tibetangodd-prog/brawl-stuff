# 📈 股海爭霸 — 虛擬股票交易遊戲

即時股票資料 + Firebase 帳號系統 + 全服聊天室 + 排行榜

---

## 🗂 專案架構

```
stock-game/
├── .github/
│   └── workflows/
│       └── update-stocks.yml    # 自動抓取股票資料 (GitHub Actions)
├── backend/
│   └── stock_fetcher.py         # Python 股票資料抓取腳本
├── frontend/
│   ├── index.html               # 遊戲主頁面
│   └── config.js                # Firebase & 遊戲設定
├── docs/
│   └── api/
│       └── stocks.json          # 自動生成的股票資料 API (GitHub Pages)
├── firebase.json                # Firebase 部署設定
├── firebase-database.rules.json # Realtime Database 安全規則
└── README.md
```

---

## 🚀 部署步驟

### 步驟一：建立 Firebase 專案

1. 前往 [Firebase Console](https://console.firebase.google.com/)
2. 點擊「新增專案」
3. 進入專案後，點選左側「建置」→「Authentication」
   - 啟用「電子郵件/密碼」登入方式
4. 點選「建置」→「Realtime Database」
   - 選擇地區（建議亞洲：asia-southeast1）
   - 先選「鎖定模式」，之後會上傳規則
5. 點選齒輪「專案設定」→「您的應用程式」→「新增應用程式」(選 Web)
6. 複製 Firebase 設定物件

### 步驟二：設定 Firebase Hosting

```bash
# 安裝 Firebase CLI
npm install -g firebase-tools

# 登入
firebase login

# 在專案根目錄初始化
firebase init

# 選擇: Hosting + Realtime Database
# Hosting public directory: frontend
# Single-page app: No
```

### 步驟三：填寫設定檔

編輯 `frontend/config.js`，填入：

```js
const FIREBASE_CONFIG = {
  apiKey: "填入你的 apiKey",
  authDomain: "你的專案.firebaseapp.com",
  databaseURL: "https://你的專案-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "你的專案",
  storageBucket: "你的專案.appspot.com",
  messagingSenderId: "填入",
  appId: "填入"
};

// 你的 GitHub Pages URL（見步驟四）
const STOCK_API_URL = "https://你的GitHub帳號.github.io/stock-game/api/stocks.json";
```

### 步驟四：建立 GitHub Repository

1. 在 GitHub 建立新的 Repository（名稱例如：`stock-game`）
2. 上傳所有專案檔案
3. 進入 Repository Settings → Pages
   - Source: 選「Deploy from a branch」
   - Branch: `main` / `docs` 資料夾
4. 等待 GitHub Pages 啟用，URL 會是：
   `https://你的GitHub帳號.github.io/stock-game/`

### 步驟五：啟用 GitHub Actions

1. 進入 Repository → Actions
2. 確認 `update-stocks.yml` workflow 已存在
3. 手動執行一次：Actions → Update Stock Data → Run workflow
4. 檢查 `docs/api/stocks.json` 是否已生成

### 步驟六：上傳 Firebase Database 規則

```bash
firebase database:rules:update firebase-database.rules.json
```

或在 Firebase Console → Realtime Database → 規則，貼入 `firebase-database.rules.json` 的內容。

### 步驟七：部署到 Firebase Hosting

```bash
firebase deploy --only hosting
```

你的遊戲網址：`https://你的專案.web.app`

---

## ⚙️ 遊戲設定說明

在 `frontend/config.js` 可調整：

| 參數 | 預設值 | 說明 |
|------|--------|------|
| `INITIAL_COINS` | 10000 | 初始遊戲幣 |
| `HOURLY_BONUS` | 500 | 每小時獎勵 |
| `BUY_FEE_RATE` | 0.001425 | 買入手續費 0.1425% |
| `SELL_FEE_RATE` | 0.001425 | 賣出手續費 0.1425% |
| `SELL_TAX_RATE` | 0.003 | 賣出證交稅 0.3% |
| `MIN_FEE` | 1 | 最低手續費 $1 |

---

## 📊 股票資料更新頻率

- 週一至五（NYSE 開市時間）：每 15 分鐘自動更新
- 週末：每小時更新一次
- 手動觸發：GitHub Actions → Run workflow

---

## 🎮 遊戲功能

- ✅ 帳號系統（Firebase Authentication）
- ✅ 初始金幣 $10,000
- ✅ 每小時自動 +$500（含倒數計時提示）
- ✅ 即時股票行情（50+ 支美股 + 台股 ADR）
- ✅ 買入/賣出操作，含手續費計算
- ✅ 持股管理與損益顯示
- ✅ 全服聊天室（Firebase Realtime Database）
- ✅ 總資產排行榜
- ✅ 交易記錄

---

## 📦 安裝 Python 依賴

```bash
pip install yfinance
```

本地測試抓取：
```bash
python backend/stock_fetcher.py
```
